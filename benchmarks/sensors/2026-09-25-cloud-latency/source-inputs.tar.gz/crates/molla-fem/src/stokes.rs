//! Stage 36.2 — incompressible Stokes / Navier-Stokes solvers using
//! Taylor-Hood (P2 velocity, P1 pressure) mixed elements.
//!
//! # Strategy
//!
//! The classical Stokes saddle-point system
//!
//! ```text
//!   [ A    Bᵀ ] [ u ]   [ f ]
//!   [ B    0  ] [ p ] = [ 0 ]
//! ```
//!
//! is **indefinite**, so the existing CG (`crates/molla/src/math/iterative.rs`)
//! cannot solve the block system directly — CG requires SPD operators.
//! Instead, we use a **SIMPLE-style projection** (Chorin / IPCS): we
//! split the velocity update from the pressure correction so each
//! sub-step is SPD-ish and CG-friendly.
//!
//! # SIMPLE iteration
//!
//! 1. **Predictor**: `A · u* = f − Bᵀ · p_old` — solve via CG on the
//!    velocity-block matrix `A` (per-component decoupled Laplacian
//!    × `μ`, plus `M / Δt` for the transient case).
//! 2. **Pressure correction**: `(B · A_diag⁻¹ · Bᵀ) · δp = −B · u*`
//!    — pressure-Poisson on the Schur complement, where `A_diag⁻¹`
//!    is the inverse of the lumped diagonal of A (cheap; gives a
//!    diagonal SPD operator). We solve via CG on the matrix-free
//!    closure `q ↦ B · (A_diag⁻¹ · (Bᵀ · q))`.
//! 3. **Update**: `u = u* − A_diag⁻¹ · Bᵀ · δp`, `p = p_old + α · δp`.
//! 4. Repeat until `‖B · u‖ < tol` (incompressibility residual).
//!
//! `α` is a relaxation factor (typical 0.7–1.0 for Stokes; lower
//! for stiff Navier-Stokes).
//!
//! # Boundary conditions
//!
//! - **Velocity**: `Dirichlet` (no-slip / lid-velocity) — pin velocity
//!   DoFs on the boundary at every component. The applier
//!   [`apply_stokes_bcs`] handles vector Dirichlet on the P2 velocity
//!   space + a single-vertex pressure pin.
//! - **Pressure**: pin one DoF (the system has a constant null space
//!   without it).
//!
//! # Caveats (v1)
//!
//! - 2D-tri + 3D-tet supported. 2D vertical-component lid-driven
//!   cavity is the contract test.
//! - Symmetric "stress" form `μ ∫ (∇u + ∇uᵀ) : ∇v` is approximated
//!   by `μ ∫ ∇u : ∇v` — equivalent for `Dirichlet` BCs everywhere
//!   (the boundary integral cancels), which is the case for the
//!   lid-driven cavity.
//! - Pressure-Poisson Schur complement uses the diagonal of `A` for
//!   `A⁻¹` (the SIMPLE approximation). Convergence is slower than
//!   exact-Schur SIMPLE but each pressure CG matvec costs only a few
//!   matvecs of `B` and `Bᵀ`.

use std::collections::HashMap;

use crate::core::Result;
use crate::math::iterative::cg_solve;
use crate::math::sparse::BsrMatrix;
use crate::math::{Real, Vec3};

use super::assembly::matvec;
use super::bc::BoundaryCondition;
use super::function_space::compute_edges;
use super::mesh::{FemCell, FemMesh};
use super::p2_element::{
    P2DofMap, p2_tet_shape_functions, p2_tet_shape_gradients, p2_tri_shape_functions,
    p2_tri_shape_gradients,
};
use super::quadrature::{tet_quadrature_11pt, tri_quadrature_6pt};

// ─── Mixed function-space helper ──────────────────────────────────────

/// Mixed Taylor-Hood velocity-pressure space description.
///
/// The velocity space is P2 vector (3 components in 3D, 2 in 2D); the
/// pressure space is P1 scalar (one DoF per vertex). The Taylor-Hood
/// pair is **LBB-stable** for incompressible Stokes — the canonical
/// safe choice for mixed element velocity-pressure formulations.
#[derive(Clone, Debug)]
pub struct MixedTaylorHood {
    /// Per-vertex velocity component count (2 for tri / 2D, 3 for
    /// tet / 3D).
    pub dim: usize,
    /// P2 DoF map (corner + edge midpoint addressing).
    pub map: P2DofMap,
    /// Total velocity DoFs = `(vertex_count + edge_count) * dim`.
    pub n_velocity: usize,
    /// Total pressure DoFs = `vertex_count`.
    pub n_pressure: usize,
}

impl MixedTaylorHood {
    /// Build the Taylor-Hood mixed space description from `mesh`.
    /// `dim = 2` for triangle meshes (planar), `dim = 3` for tets.
    #[must_use]
    pub fn build(mesh: &FemMesh, dim: usize) -> Self {
        assert!(dim == 2 || dim == 3, "Taylor-Hood: dim must be 2 or 3");
        let map = P2DofMap::build(mesh);
        let n_v_nodes = map.ndof();
        let n_velocity = n_v_nodes * dim;
        let n_pressure = mesh.vert_count();
        Self {
            dim,
            map,
            n_velocity,
            n_pressure,
        }
    }

    /// Velocity DoF count.
    #[must_use]
    pub fn ndof_velocity(&self) -> usize {
        self.n_velocity
    }

    /// Pressure DoF count.
    #[must_use]
    pub fn ndof_pressure(&self) -> usize {
        self.n_pressure
    }

    /// Convert a P2 node index (`0..n_v_nodes`) + component (`0..dim`)
    /// into a flat global velocity DoF using the **interleaved** layout
    /// `node * dim + comp`.
    #[inline]
    #[must_use]
    pub fn velocity_dof(&self, node: usize, comp: usize) -> usize {
        node * self.dim + comp
    }
}

// ─── Element matrices ─────────────────────────────────────────────────

/// Local **velocity-block** matrix
/// `A^e_{(i, c), (j, c')} = δ_{c, c'} · μ · ∫ ∇N_i^v · ∇N_j^v dx`
/// for one Taylor-Hood cell (P2 velocity).
///
/// The cross-component coupling vanishes because the simplified
/// Laplacian form `μ ∇u : ∇v` decouples per component. The returned
/// matrix is the standard P2 stiffness matrix replicated on
/// `dim`-block-diagonals, in **interleaved local layout** `local DoF
/// = node * dim + component`. Shape: `(N · dim) × (N · dim)` where
/// `N = 6` (tri) or `N = 10` (tet).
#[must_use]
pub fn compute_element_stokes_velocity_block(
    cell: &FemCell,
    vertices: &[Vec3],
    viscosity: Real,
    dim: usize,
) -> Vec<Vec<Real>> {
    debug_assert!(dim == 2 || dim == 3);
    match cell {
        FemCell::Tri(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
            ];
            let area = super::element::tri_area_2d(&p);
            let qpts = tri_quadrature_6pt();
            let n = 6;
            let n_dof = n * dim;
            let mut k = vec![vec![0.0_f64 as Real; n_dof]; n_dof];
            for q in &qpts {
                let g = p2_tri_shape_gradients(q.bary, &p);
                let w = q.weight * area * viscosity;
                for i in 0..n {
                    for j in 0..n {
                        // 2D dot product (z = 0 for planar tris).
                        let gg = g[i].x * g[j].x + g[i].y * g[j].y;
                        for c in 0..dim {
                            k[i * dim + c][j * dim + c] += w * gg;
                        }
                    }
                }
            }
            k
        }
        FemCell::Tet(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
                vertices[idx[3] as usize],
            ];
            let vol = super::element::tet_volume(&p);
            let qpts = tet_quadrature_11pt();
            let n = 10;
            let n_dof = n * dim;
            let mut k = vec![vec![0.0_f64 as Real; n_dof]; n_dof];
            for q in &qpts {
                let g = p2_tet_shape_gradients(q.bary, &p);
                let w = q.weight * vol * viscosity;
                for i in 0..n {
                    for j in 0..n {
                        let gg = g[i].dot(g[j]);
                        for c in 0..dim {
                            k[i * dim + c][j * dim + c] += w * gg;
                        }
                    }
                }
            }
            k
        }
    }
}

/// Local **divergence-block** matrix
/// `B^e_{q, (j, c)} = ∫ N_q^p · ∂N_j^v / ∂x_c dx` for one Taylor-Hood
/// cell (P1 pressure × ∂P2 velocity).
///
/// Shape: `n_p × (n_v · dim)` where:
/// - tri: `3 × (6 · 2) = 3 × 12`,
/// - tet: `4 × (10 · 3) = 4 × 30`.
///
/// Local layout: rows are pressure node indices `0..n_p`; columns use
/// the same **interleaved** `node * dim + component` layout as
/// [`compute_element_stokes_velocity_block`].
#[must_use]
pub fn compute_element_stokes_div_block(
    cell: &FemCell,
    vertices: &[Vec3],
    dim: usize,
) -> Vec<Vec<Real>> {
    debug_assert!(dim == 2 || dim == 3);
    match cell {
        FemCell::Tri(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
            ];
            let area = super::element::tri_area_2d(&p);
            let qpts = tri_quadrature_6pt();
            let n_v = 6;
            let n_p = 3;
            let n_dof_v = n_v * dim;
            let mut b = vec![vec![0.0_f64 as Real; n_dof_v]; n_p];
            for q in &qpts {
                let np = p2_tri_shape_functions(q.bary); // also have P1 = bary directly
                let g = p2_tri_shape_gradients(q.bary, &p);
                // P1 pressure shape functions on a tri are the
                // barycentric coords themselves: `λ_0, λ_1, λ_2`.
                let pq = q.bary;
                let w = q.weight * area;
                let _ = np; // P2 shape unused for pressure
                for ip in 0..n_p {
                    for jv in 0..n_v {
                        for c in 0..dim {
                            let dn = if c == 0 { g[jv].x } else { g[jv].y };
                            b[ip][jv * dim + c] += w * pq[ip] * dn;
                        }
                    }
                }
            }
            b
        }
        FemCell::Tet(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
                vertices[idx[3] as usize],
            ];
            let vol = super::element::tet_volume(&p);
            let qpts = tet_quadrature_11pt();
            let n_v = 10;
            let n_p = 4;
            let n_dof_v = n_v * dim;
            let mut b = vec![vec![0.0_f64 as Real; n_dof_v]; n_p];
            for q in &qpts {
                let g = p2_tet_shape_gradients(q.bary, &p);
                let pq = q.bary; // P1 pressure shape = barycentric coords
                let w = q.weight * vol;
                for ip in 0..n_p {
                    for jv in 0..n_v {
                        let comp = [g[jv].x, g[jv].y, g[jv].z];
                        for c in 0..dim {
                            b[ip][jv * dim + c] += w * pq[ip] * comp[c];
                        }
                    }
                }
            }
            b
        }
    }
}

/// Local **vector mass** matrix
/// `M^e_{(i, c), (j, c')} = δ_{c, c'} · ∫ N_i^v N_j^v dx` for one
/// P2-vector cell — the time-stepping mass for transient Navier-Stokes.
///
/// Returned in interleaved layout matching
/// [`compute_element_stokes_velocity_block`]. Shape: `(N · dim) ×
/// (N · dim)`.
#[must_use]
pub fn compute_element_mass_p2_vector(
    cell: &FemCell,
    vertices: &[Vec3],
    dim: usize,
) -> Vec<Vec<Real>> {
    debug_assert!(dim == 2 || dim == 3);
    match cell {
        FemCell::Tri(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
            ];
            let area = super::element::tri_area_2d(&p);
            let qpts = tri_quadrature_6pt();
            let n = 6;
            let n_dof = n * dim;
            let mut m = vec![vec![0.0_f64 as Real; n_dof]; n_dof];
            for q in &qpts {
                let np = p2_tri_shape_functions(q.bary);
                let w = q.weight * area;
                for i in 0..n {
                    for j in 0..n {
                        let nn = np[i] * np[j];
                        for c in 0..dim {
                            m[i * dim + c][j * dim + c] += w * nn;
                        }
                    }
                }
            }
            m
        }
        FemCell::Tet(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
                vertices[idx[3] as usize],
            ];
            let vol = super::element::tet_volume(&p);
            let qpts = tet_quadrature_11pt();
            let n = 10;
            let n_dof = n * dim;
            let mut m = vec![vec![0.0_f64 as Real; n_dof]; n_dof];
            for q in &qpts {
                let np = p2_tet_shape_functions(q.bary);
                let w = q.weight * vol;
                for i in 0..n {
                    for j in 0..n {
                        let nn = np[i] * np[j];
                        for c in 0..dim {
                            m[i * dim + c][j * dim + c] += w * nn;
                        }
                    }
                }
            }
            m
        }
    }
}

// ─── Assembly ────────────────────────────────────────────────────────

/// Assemble the global P2-vector velocity-block matrix `A` for the
/// Stokes system. CSR with `(n_v_nodes · dim)` rows and columns.
pub fn assemble_velocity_block(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    viscosity: Real,
) -> Result<BsrMatrix> {
    let n = th.n_velocity;
    let dim = th.dim;
    // Flat scalar triplets — avoids the per-entry `vec![val]` alloc.
    let mut triplets: Vec<(usize, usize, Real)> =
        Vec::with_capacity(mesh.cells.len() * 100 * dim * dim);
    for cell in &mesh.cells {
        let local = compute_element_stokes_velocity_block(cell, &mesh.vertices, viscosity, dim);
        let n_local_nodes = match cell {
            FemCell::Tri(_) => 6,
            FemCell::Tet(_) => 10,
        };
        for i in 0..n_local_nodes {
            let gi_node = th.map.local_to_global(cell, i);
            for j in 0..n_local_nodes {
                let gj_node = th.map.local_to_global(cell, j);
                for ci in 0..dim {
                    for cj in 0..dim {
                        let val = local[i * dim + ci][j * dim + cj];
                        if val == 0.0 {
                            continue;
                        }
                        triplets.push((gi_node * dim + ci, gj_node * dim + cj, val));
                    }
                }
            }
        }
    }
    BsrMatrix::from_scalar_triplets(n, n, &triplets)
}

/// Local **mixed-elasticity velocity block**
/// `K^e = ∫ 2μ ε(u):ε(v) dx` on P2 elements (Stage: INSPECTION.md
/// F15 / WarpFemMixedElasticity). Unlike the Stokes full-gradient
/// block this couples components:
/// `K[(i,a),(j,b)] = μ ∫ (δ_ab ∇φᵢ·∇φⱼ + ∂_b φᵢ ∂_a φⱼ)`.
/// The λ div·div term is deliberately ABSENT — the pressure carries
/// it through the saddle constraint `p = λ div u`, which is what
/// prevents volumetric locking as ν → ½.
#[must_use]
pub fn compute_element_mixed_elastic_block(
    cell: &FemCell,
    vertices: &[Vec3],
    mu: Real,
    dim: usize,
) -> Vec<Vec<Real>> {
    debug_assert!(dim == 2 || dim == 3);
    let axis = |g: &Vec3, c: usize| -> Real {
        match c {
            0 => g.x,
            1 => g.y,
            _ => g.z,
        }
    };
    match cell {
        FemCell::Tri(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
            ];
            let area = super::element::tri_area_2d(&p);
            let qpts = tri_quadrature_6pt();
            let n = 6;
            let n_dof = n * dim;
            let mut k = vec![vec![0.0_f64 as Real; n_dof]; n_dof];
            for q in &qpts {
                let g = p2_tri_shape_gradients(q.bary, &p);
                let w = q.weight * area * mu;
                for i in 0..n {
                    for j in 0..n {
                        let gg = g[i].x * g[j].x + g[i].y * g[j].y;
                        for a in 0..dim {
                            for b in 0..dim {
                                let mut val = axis(&g[i], b) * axis(&g[j], a);
                                if a == b {
                                    val += gg;
                                }
                                k[i * dim + a][j * dim + b] += w * val;
                            }
                        }
                    }
                }
            }
            k
        }
        FemCell::Tet(idx) => {
            let p = [
                vertices[idx[0] as usize],
                vertices[idx[1] as usize],
                vertices[idx[2] as usize],
                vertices[idx[3] as usize],
            ];
            let vol = super::element::tet_volume(&p);
            let qpts = tet_quadrature_11pt();
            let n = 10;
            let n_dof = n * dim;
            let mut k = vec![vec![0.0_f64 as Real; n_dof]; n_dof];
            for q in &qpts {
                let g = p2_tet_shape_gradients(q.bary, &p);
                let w = q.weight * vol * mu;
                for i in 0..n {
                    for j in 0..n {
                        let gg = g[i].dot(g[j]);
                        for a in 0..dim {
                            for b in 0..dim {
                                let mut val = axis(&g[i], b) * axis(&g[j], a);
                                if a == b {
                                    val += gg;
                                }
                                k[i * dim + a][j * dim + b] += w * val;
                            }
                        }
                    }
                }
            }
            k
        }
    }
}

/// Assemble the global mixed-elasticity block `A = ∫ 2μ ε:ε`.
pub fn assemble_mixed_elastic_block(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    mu: Real,
) -> Result<BsrMatrix> {
    let n = th.n_velocity;
    let dim = th.dim;
    let mut triplets: Vec<(usize, usize, Real)> =
        Vec::with_capacity(mesh.cells.len() * 100 * dim * dim);
    for cell in &mesh.cells {
        let local = compute_element_mixed_elastic_block(cell, &mesh.vertices, mu, dim);
        let n_local_nodes = match cell {
            FemCell::Tri(_) => 6,
            FemCell::Tet(_) => 10,
        };
        for i in 0..n_local_nodes {
            let gi_node = th.map.local_to_global(cell, i);
            for j in 0..n_local_nodes {
                let gj_node = th.map.local_to_global(cell, j);
                for ci in 0..dim {
                    for cj in 0..dim {
                        let val = local[i * dim + ci][j * dim + cj];
                        if val == 0.0 {
                            continue;
                        }
                        triplets.push((gi_node * dim + ci, gj_node * dim + cj, val));
                    }
                }
            }
        }
    }
    BsrMatrix::from_scalar_triplets(n, n, &triplets)
}

/// Assemble the P1 pressure mass matrix `M_p` (consistent):
/// `∫ N_q N_r = |E|/12·(1+δ_qr)` on tris, `|E|/20·(1+δ_qr)` on tets.
pub fn assemble_pressure_mass(mesh: &FemMesh, th: &MixedTaylorHood) -> Result<BsrMatrix> {
    let n = th.n_pressure;
    let mut triplets: Vec<(usize, usize, Real)> = Vec::with_capacity(mesh.cells.len() * 16);
    for cell in &mesh.cells {
        match cell {
            FemCell::Tri(idx) => {
                let p = [
                    mesh.vertices[idx[0] as usize],
                    mesh.vertices[idx[1] as usize],
                    mesh.vertices[idx[2] as usize],
                ];
                let area = super::element::tri_area_2d(&p);
                for q in 0..3 {
                    for r in 0..3 {
                        let val = area / 12.0 * if q == r { 2.0 } else { 1.0 };
                        triplets.push((idx[q] as usize, idx[r] as usize, val));
                    }
                }
            }
            FemCell::Tet(idx) => {
                let p = [
                    mesh.vertices[idx[0] as usize],
                    mesh.vertices[idx[1] as usize],
                    mesh.vertices[idx[2] as usize],
                    mesh.vertices[idx[3] as usize],
                ];
                let vol = super::element::tet_volume(&p);
                for q in 0..4 {
                    for r in 0..4 {
                        let val = vol / 20.0 * if q == r { 2.0 } else { 1.0 };
                        triplets.push((idx[q] as usize, idx[r] as usize, val));
                    }
                }
            }
        }
    }
    BsrMatrix::from_scalar_triplets(n, n, &triplets)
}

/// Assemble the global P2-vector velocity-mass matrix `M` (consistent).
pub fn assemble_velocity_mass(mesh: &FemMesh, th: &MixedTaylorHood) -> Result<BsrMatrix> {
    let n = th.n_velocity;
    let dim = th.dim;
    // Flat scalar triplets — see `assemble_velocity_block`.
    let mut triplets: Vec<(usize, usize, Real)> =
        Vec::with_capacity(mesh.cells.len() * 100 * dim * dim);
    for cell in &mesh.cells {
        let local = compute_element_mass_p2_vector(cell, &mesh.vertices, dim);
        let n_local_nodes = match cell {
            FemCell::Tri(_) => 6,
            FemCell::Tet(_) => 10,
        };
        for i in 0..n_local_nodes {
            let gi_node = th.map.local_to_global(cell, i);
            for j in 0..n_local_nodes {
                let gj_node = th.map.local_to_global(cell, j);
                for ci in 0..dim {
                    for cj in 0..dim {
                        let val = local[i * dim + ci][j * dim + cj];
                        if val == 0.0 {
                            continue;
                        }
                        triplets.push((gi_node * dim + ci, gj_node * dim + cj, val));
                    }
                }
            }
        }
    }
    BsrMatrix::from_scalar_triplets(n, n, &triplets)
}

/// Assemble the global divergence matrix `B` (P1 pressure × ∂P2
/// velocity). Shape: `n_pressure × n_velocity`.
pub fn assemble_div_block(mesh: &FemMesh, th: &MixedTaylorHood) -> Result<BsrMatrix> {
    let n_p = th.n_pressure;
    let n_v = th.n_velocity;
    let dim = th.dim;
    // Flat scalar triplets — see `assemble_velocity_block`.
    let mut triplets: Vec<(usize, usize, Real)> = Vec::with_capacity(mesh.cells.len() * 4 * 30);
    for cell in &mesh.cells {
        let local = compute_element_stokes_div_block(cell, &mesh.vertices, dim);
        let (n_p_local, n_v_local, p_verts) = match cell {
            FemCell::Tri(v) => (3usize, 6usize, &v[..]),
            FemCell::Tet(v) => (4usize, 10usize, &v[..]),
        };
        for ip in 0..n_p_local {
            let gip = p_verts[ip] as usize;
            for jv in 0..n_v_local {
                let gjv_node = th.map.local_to_global(cell, jv);
                for c in 0..dim {
                    let val = local[ip][jv * dim + c];
                    if val == 0.0 {
                        continue;
                    }
                    triplets.push((gip, gjv_node * dim + c, val));
                }
            }
        }
    }
    BsrMatrix::from_scalar_triplets(n_p, n_v, &triplets)
}

// ─── Boundary conditions ──────────────────────────────────────────────

/// Boundary-condition kinds specific to incompressible flow.
///
/// These extend the scalar `BoundaryCondition::Dirichlet` enum (used
/// for heat-equation and elasticity); the Stokes solver applies them
/// directly without re-using the elasticity DirichletVector path
/// because the velocity-DoF layout differs (corner + edge nodes).
#[derive(Clone, Debug)]
pub enum StokesBc {
    /// No-slip wall: pin every velocity component at the given P2 node
    /// to zero.
    NoSlip { node: u32 },
    /// Lid / moving-wall: pin every velocity component at the given P2
    /// node to the prescribed value (length must be `dim`).
    LidVelocity { node: u32, velocity: Vec<Real> },
    /// Pressure pin: pin a single pressure DoF (one mesh vertex) to
    /// the given scalar — usually 0. Required to break the constant
    /// null-space of the pressure-Poisson system.
    PressureZero { vertex: u32 },
}

/// Apply Stokes BCs in-place on the velocity-block matrix `A`,
/// pressure operator (currently a no-op except for the pressure pin
/// which the caller applies on the Schur system) and the velocity RHS
/// vector. Returns the list of velocity DoFs that were pinned (for the
/// pressure-correction step which must zero-out those rows of `B^T`).
pub fn apply_stokes_velocity_bcs(
    a: &mut BsrMatrix,
    f: &mut [Real],
    bcs: &[StokesBc],
    dim: usize,
) -> Vec<usize> {
    let mut pinned = Vec::new();
    for bc in bcs {
        match bc {
            StokesBc::NoSlip { node } => {
                let base = (*node as usize) * dim;
                for c in 0..dim {
                    pin_row_a(a, f, base + c, 0.0);
                    pinned.push(base + c);
                }
            }
            StokesBc::LidVelocity { node, velocity } => {
                debug_assert_eq!(velocity.len(), dim);
                let base = (*node as usize) * dim;
                for (c, v) in velocity.iter().enumerate() {
                    pin_row_a(a, f, base + c, *v);
                    pinned.push(base + c);
                }
            }
            // Pressure pin handled separately on the Schur system.
            StokesBc::PressureZero { .. } => {}
        }
    }
    pinned
}

/// Internal helper — zero row `r`, set diagonal to 1, set `f[r] = value`.
fn pin_row_a(k: &mut BsrMatrix, f: &mut [Real], r: usize, value: Real) {
    let lo = k.row_offsets[r];
    let hi = k.row_offsets[r + 1];
    for slot in lo..hi {
        let c = k.col_idx[slot];
        k.values[slot] = if c == r { 1.0 } else { 0.0 };
    }
    f[r] = value;
}

/// Symmetric Dirichlet enforcement on a CSR matrix: given the set of
/// pinned DoFs and their target values, eliminate the column terms by
/// subtracting `A[r][d] * v_d` from `f[r]` for every other row, then
/// zero those off-diagonal column entries; finally pin each pinned
/// row to identity. Result: matrix stays SPD on the unconstrained
/// block, RHS is consistent.
fn apply_symmetric_dirichlet(k: &mut BsrMatrix, f: &mut [Real], pinned: &[(usize, Real)]) {
    use std::collections::HashMap;
    let pin_map: HashMap<usize, Real> = pinned.iter().copied().collect();
    // Pass 1: eliminate columns by moving their contribution to the RHS,
    // for every row that touches a pinned column. Avoid mutating the
    // pinned rows themselves (we'll reset them next).
    for r in 0..k.block_rows {
        if pin_map.contains_key(&r) {
            continue;
        }
        let lo = k.row_offsets[r];
        let hi = k.row_offsets[r + 1];
        for slot in lo..hi {
            let c = k.col_idx[slot];
            if let Some(v) = pin_map.get(&c) {
                f[r] -= k.values[slot] * v;
                k.values[slot] = 0.0;
            }
        }
    }
    // Pass 2: pin each constrained row to identity, RHS = value.
    for (r, v) in pinned {
        let lo = k.row_offsets[*r];
        let hi = k.row_offsets[*r + 1];
        for slot in lo..hi {
            let c = k.col_idx[slot];
            k.values[slot] = if c == *r { 1.0 } else { 0.0 };
        }
        f[*r] = *v;
    }
}

/// Apply velocity BCs from the legacy `BoundaryCondition` enum.
///
/// Maps `Dirichlet { vertex, value }` → no-slip on `vertex` (component
/// 0 = `value`, others 0); `DirichletVector { vertex, values }` →
/// lid-velocity on `vertex` with the given component values.
///
/// Provided so callers can use the existing BC plumbing without
/// constructing a parallel `StokesBc` list.
pub fn apply_stokes_bcs_legacy(
    a: &mut BsrMatrix,
    f: &mut [Real],
    bcs: &[BoundaryCondition],
    dim: usize,
) -> Vec<usize> {
    let mut pinned = Vec::new();
    for bc in bcs {
        match bc {
            BoundaryCondition::DirichletVector { vertex, values } => {
                let base = (*vertex as usize) * dim;
                for (c, v) in values.iter().enumerate().take(dim) {
                    pin_row_a(a, f, base + c, *v);
                    pinned.push(base + c);
                }
            }
            BoundaryCondition::Dirichlet { vertex, value } => {
                let base = (*vertex as usize) * dim;
                pin_row_a(a, f, base, *value);
                pinned.push(base);
                for c in 1..dim {
                    pin_row_a(a, f, base + c, 0.0);
                    pinned.push(base + c);
                }
            }
            _ => {}
        }
    }
    pinned
}

// ─── Solver: steady-state Stokes ──────────────────────────────────────

/// Solver tuning for the Uzawa-CG iteration on the pressure-Schur
/// system.
///
/// **History**: The original SIMPLE iteration (`u* = A⁻¹ rhs`,
/// `dp = (B diag(A)⁻¹ Bᵀ)⁻¹ (-Bu*)`, `p ← p + α dp`) was numerically
/// unstable on lid-driven cavity even at modest mesh sizes — `diag(A)`
/// is a poor proxy for `A⁻¹` on the Laplacian-style velocity block,
/// and the relaxation parameter required to damp the divergence was
/// vanishingly small. We swapped in **Uzawa-CG**: solve the
/// pressure-Schur system `S p = B A⁻¹ f` with CG, where each `S q`
/// is computed by an inner CG on `A`. Convergence is robust at the
/// price of nested CG iterations. The `alpha_p` field is preserved
/// for back-compat / future SIMPLE-relaxation experiments but is
/// currently unused by the Uzawa path.
#[derive(Clone, Debug)]
pub struct StokesSimpleConfig {
    /// Pressure relaxation factor (currently unused; kept for SIMPLE
    /// API compatibility).
    pub alpha_p: Real,
    /// Outer CG (pressure-Schur) iteration cap.
    pub max_outer_iters: usize,
    /// Outer CG tolerance — relative against `‖g‖` where
    /// `g = B A⁻¹ f_red`.
    pub tol_outer: Real,
    /// Inner CG iteration cap (each `A x = y` solve).
    pub max_inner_iters: usize,
    /// Inner CG tolerance.
    pub tol_inner: Real,
}

impl Default for StokesSimpleConfig {
    fn default() -> Self {
        Self {
            alpha_p: 0.8,
            max_outer_iters: 200,
            tol_outer: 1.0e-7,
            max_inner_iters: 2000,
            tol_inner: 1.0e-10,
        }
    }
}

/// Solver outcome for the steady-state Stokes solve.
#[derive(Clone, Debug)]
pub struct StokesResult {
    /// Velocity DoF vector.
    pub u: Vec<Real>,
    /// Pressure DoF vector.
    pub p: Vec<Real>,
    /// Number of SIMPLE outer iterations consumed.
    pub outer_iters: usize,
    /// Final incompressibility residual `‖B u‖`.
    pub div_residual: Real,
}

/// Solve the **steady-state** incompressible Stokes problem
///
/// ```text
///   −μ ∇²u + ∇p = f
///         ∇ · u = 0
/// ```
///
/// via SIMPLE iteration on the Taylor-Hood (P2-P1) discretization.
///
/// `f_velocity` is the velocity-side body-force RHS (e.g. gravity);
/// pass an all-zero vector for the canonical lid-driven cavity.
///
/// `bcs` contains [`StokesBc`] entries (no-slip, lid velocity, and
/// optionally a [`StokesBc::PressureZero`] pin to break the constant
/// null space of the pressure system). If no pressure pin is supplied,
/// vertex 0 is pinned to 0 by default.
pub fn solve_stokes_steady(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    f_velocity: &[Real],
    viscosity: Real,
    bcs: &[StokesBc],
    cfg: &StokesSimpleConfig,
) -> Result<StokesResult> {
    debug_assert_eq!(f_velocity.len(), th.n_velocity);

    let a = assemble_velocity_block(mesh, th, viscosity)?;
    let b_div = assemble_div_block(mesh, th)?;

    solve_stokes_with_matrices(th, &a, &b_div, f_velocity, bcs, cfg)
}

/// Lower-level Uzawa-CG entry point: caller supplies the pre-assembled
/// velocity-block matrix `A` (which may include a `M/Δt` term for
/// transient steps) and the divergence matrix `B`. Returns the
/// `(u, p)` Stokes solve at the given RHS.
pub fn solve_stokes_with_matrices(
    th: &MixedTaylorHood,
    a: &BsrMatrix,
    b_div: &BsrMatrix,
    f_velocity: &[Real],
    bcs: &[StokesBc],
    cfg: &StokesSimpleConfig,
) -> Result<StokesResult> {
    solve_saddle_with_matrices(th, a, b_div, f_velocity, bcs, cfg, None)
}

/// INSPECTION.md F15 / WarpFemMixedElasticity — nearly-incompressible
/// mixed (u, p) linear elasticity on Taylor-Hood elements:
///
/// ```text
///   ∫ 2μ ε(u):ε(v) + ∫ p div v = ∫ f·v      (momentum)
///   ∫ q div u − (1/λ) ∫ p q    = 0          (p = λ div u)
/// ```
///
/// The λ div·div term never enters the displacement operator, so the
/// formulation cannot volumetrically lock as ν → ½ (λ → ∞ recovers
/// exact incompressibility / Stokes). `f_velocity` is the assembled
/// P2 load vector; `bcs` reuse the Stokes Dirichlet plumbing.
pub fn solve_mixed_elasticity_steady(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    mu: Real,
    lambda: Real,
    f_velocity: &[Real],
    bcs: &[StokesBc],
    cfg: &StokesSimpleConfig,
) -> Result<StokesResult> {
    let a = assemble_mixed_elastic_block(mesh, th, mu)?;
    let b = assemble_div_block(mesh, th)?;
    let m_p = assemble_pressure_mass(mesh, th)?;
    let scale = if lambda.is_finite() && lambda > 0.0 {
        1.0 / lambda
    } else {
        0.0
    };
    solve_saddle_with_matrices(th, &a, &b, f_velocity, bcs, cfg, Some((&m_p, scale)))
}

/// Shared Uzawa-CG saddle solver. With `compliance = Some((M_p, s))`
/// the constraint becomes `B u − s·M_p p = 0` (Schur gains `+ s·M_p`),
/// which is the nearly-incompressible mixed-elasticity relaxation
/// `p = λ div u` at `s = 1/λ` (INSPECTION.md F15 /
/// WarpFemMixedElasticity); `None` is exact incompressibility
/// (Stokes).
#[allow(clippy::too_many_arguments)]
fn solve_saddle_with_matrices(
    th: &MixedTaylorHood,
    a: &BsrMatrix,
    b_div: &BsrMatrix,
    f_velocity: &[Real],
    bcs: &[StokesBc],
    cfg: &StokesSimpleConfig,
    compliance: Option<(&BsrMatrix, Real)>,
) -> Result<StokesResult> {
    debug_assert_eq!(f_velocity.len(), th.n_velocity);
    debug_assert_eq!(a.nrows(), th.n_velocity);
    debug_assert_eq!(b_div.nrows(), th.n_pressure);
    debug_assert_eq!(b_div.ncols(), th.n_velocity);

    let n_v = th.n_velocity;
    let n_p = th.n_pressure;

    // Build the velocity Dirichlet (DoF, value) list once.
    let pinned_pairs = collect_velocity_pins(bcs, th.dim);
    let pinned_set: std::collections::HashSet<usize> =
        pinned_pairs.iter().map(|(d, _)| *d).collect();

    // Symmetric-Dirichlet reduction of A. f_red starts at f_velocity
    // and gets updated by the column elimination.
    let mut a_red = a.clone();
    let mut f_red = f_velocity.to_vec();
    apply_symmetric_dirichlet(&mut a_red, &mut f_red, &pinned_pairs);

    // Identify "dead" pressure rows — pressure DoFs whose every
    // velocity column lies in the pinned set. These rows produce a
    // zero diagonal in the Schur complement (LBB / inf-sup violation
    // for that DoF on this coarse mesh) and would make CG diverge.
    // Pin them all to zero so they fall out of the system.
    //
    // Threshold is scaled by `‖B‖∞` so it tracks the matrix
    // magnitude — on a mm-scale mesh every entry of B is ~1e-9 and a
    // hard `1e-14` floor would falsely flag every row as dead.
    let b_inf_norm = b_div
        .values
        .iter()
        .copied()
        .map(Real::abs)
        .fold(0.0_f64, Real::max);
    let dead_threshold = (1e-12 * b_inf_norm).max(1e-30);
    let mut dead_pressure_rows: std::collections::HashSet<usize> = std::collections::HashSet::new();
    // With a compliance term the Schur operator is `B A⁻¹ Bᵀ + s·M_p`,
    // whose M_p part keeps every row definite — pinning "dead" rows
    // would wrongly force boundary pressures to zero (breaks the
    // constant-strain patch test).
    let detect_dead = compliance.is_none();
    for r in 0..n_p {
        if !detect_dead {
            break;
        }
        let lo = b_div.row_offsets[r];
        let hi = b_div.row_offsets[r + 1];
        let mut alive = false;
        for slot in lo..hi {
            let c = b_div.col_idx[slot];
            if !pinned_set.contains(&c) && b_div.values[slot].abs() > dead_threshold {
                alive = true;
                break;
            }
        }
        if !alive {
            dead_pressure_rows.insert(r);
        }
    }

    // Pressure pin (default: vertex 0).
    // Default pressure pin: required for exact incompressibility
    // (constant pressure nullspace) but WRONG with a compliance term —
    // there `S = B A⁻¹ Bᵀ + s·M_p` is already definite, and pinning a
    // vertex to zero corrupts the solution (caught by the mixed-
    // elasticity constant-strain patch test, where the exact pressure
    // is a nonzero constant). Explicit `PressureZero` BCs are always
    // honored.
    let p_pin = bcs
        .iter()
        .find_map(|b| {
            if let StokesBc::PressureZero { vertex } = b {
                Some(*vertex as usize)
            } else {
                None
            }
        })
        .or(if compliance.is_none() { Some(0) } else { None });

    // Treat all "dead" pressure rows + the explicit pin as one set of
    // pressure DoFs to enforce-as-zero in the Schur complement.
    let mut p_pinned_set: std::collections::HashSet<usize> = dead_pressure_rows.clone();
    if let Some(pp) = p_pin {
        p_pinned_set.insert(pp);
    }

    let mut u = vec![0.0; n_v];
    for &(dof, val) in &pinned_pairs {
        u[dof] = val;
    }
    let mut p = vec![0.0; n_p];

    // ── Outer Uzawa-CG iteration ──────────────────────────────────
    //
    // The pure SIMPLE iteration (using `D = diag(A)` as the inverse
    // approximation) blew up on the cavity test — `D⁻¹` is far too
    // permissive of a stand-in for `A⁻¹` on a Laplacian-like operator
    // and the relaxation parameter would have to be vanishingly small.
    //
    // Instead we use **Uzawa-CG**: solve the saddle-point system as a
    // Schur-complement on the pressure where the Schur action
    // `S p = B A⁻¹ Bᵀ p` is computed via an inner CG on `A` for each
    // pressure-side matvec. CG on `S` then converges in O(k_press)
    // iterations regardless of the velocity-side conditioning.
    //
    // The inner-CG uses a relaxed tolerance (`tol_inner_inner`) since
    // each pressure-CG iteration only needs `S p` to a few digits;
    // wasted work in inner CG dominates the wall-clock otherwise.

    // Initial RHS norm — used below to scale the outer pressure
    // tolerance so `tol_outer` is **relative** (independent of the
    // forcing magnitude), matching the user's intuition.
    let f_norm_init = (f_velocity.iter().map(|x| x * x).sum::<Real>())
        .sqrt()
        .max(1.0);

    // Pre-compute `A⁻¹ f_red`: shows up in both RHS and the action.
    let a_inv_f = solve_inner_cg(&a_red, &f_red, &vec![0.0; n_v], cfg);

    // RHS of pressure-Schur equation: g = B · (A⁻¹ f_red) − (boundary
    // term) — for our enforced-row symmetric pinning, the RHS is
    // simply `B · (A⁻¹ f_red)` because the column-elim already moved
    // BC contributions into f_red.
    let mut g = matvec(b_div, &a_inv_f);
    // Pin pressure rows to zero in the equation.
    for &r in p_pinned_set.iter() {
        g[r] = 0.0;
    }

    // Schur op: p ↦ B · (A_red⁻¹ · Bᵀ p), with pinned rows behaving as
    // identity.
    let p_pinned_set_ref = &p_pinned_set;
    let pinned_set_ref = &pinned_set;
    let a_red_ref = &a_red;
    let cfg_ref = &cfg;
    let schur_op = |q: &[Real]| -> Vec<Real> {
        let mut q_eff = q.to_vec();
        for &r in p_pinned_set_ref.iter() {
            q_eff[r] = 0.0;
        }
        // x = Bᵀ q_eff
        let mut x = matvec_t(b_div, &q_eff, n_v);
        // Pinned velocity DoFs: zero (homogeneous Dirichlet on the
        // perturbation Bᵀq side).
        for &dof in pinned_set_ref.iter() {
            x[dof] = 0.0;
        }
        // y = A_red⁻¹ x  (inner CG)
        let y_v = solve_inner_cg(a_red_ref, &x, &vec![0.0; n_v], cfg_ref);
        // p = B y
        let mut yout = matvec(b_div, &y_v);
        // Mixed-elasticity compliance: Schur = B A⁻¹ Bᵀ + s·M_p.
        if let Some((m_p, scale)) = compliance {
            let mq = matvec(m_p, &q_eff);
            for (o, m) in yout.iter_mut().zip(mq.iter()) {
                *o += scale * m;
            }
        }
        // Identity rows for pinned pressures.
        for &r in p_pinned_set_ref.iter() {
            yout[r] = q[r];
        }
        yout
    };

    // Solve pressure system via CG. The outer "iteration count" here
    // is the CG iteration count. Scale the requested `tol_outer`
    // (which the caller intends as relative to the forcing) by
    // `f_norm_init` so the actual CG tolerance tracks the input
    // magnitude — `cg_solve` measures `‖r‖` against the RHS norm of
    // the Schur system `g = B·A⁻¹·f_red`, which can be many orders
    // of magnitude smaller than `‖f_red‖` for nearly-divergence-free
    // forcing (e.g. lid-driven cavity), so without this scaling the
    // user-facing tolerance is silently looser than configured.
    let p_init = p.clone();
    let tol_scaled = cfg.tol_outer * f_norm_init;
    let p_res = cg_solve(schur_op, &g, &p_init, tol_scaled, cfg.max_outer_iters);
    p = p_res.x;
    for &r in p_pinned_set.iter() {
        p[r] = 0.0;
    }

    // Recover velocity: u = A⁻¹ (f_red − Bᵀ p).
    let bt_p = matvec_t(b_div, &p, n_v);
    let mut rhs_u: Vec<Real> = (0..n_v).map(|i| f_red[i] - bt_p[i]).collect();
    for &(dof, val) in &pinned_pairs {
        rhs_u[dof] = val;
    }
    u = solve_inner_cg(&a_red, &rhs_u, &u, cfg);

    let bu = matvec(b_div, &u);
    // Compute the divergence residual on the FREE pressure rows only —
    // the dead/pinned rows carry the BC-driven divergence that the
    // discretisation cannot zero (their pressure was forced to 0).
    let mut div_residual_free_sq = 0.0;
    let mut div_residual_dead_sq = 0.0;
    for (r, &v) in bu.iter().enumerate() {
        if p_pinned_set.contains(&r) {
            div_residual_dead_sq += v * v;
        } else {
            div_residual_free_sq += v * v;
        }
    }
    let div_residual = div_residual_free_sq.sqrt();
    let _div_residual_dead = div_residual_dead_sq.sqrt();
    let outer_iters = p_res.iters;

    Ok(StokesResult {
        u,
        p,
        outer_iters,
        div_residual,
    })
}

/// Inner CG solve helper for the Uzawa outer iteration. Always
/// returns a finite vector (CG bails at iteration cap on stagnation).
fn solve_inner_cg(a: &BsrMatrix, b: &[Real], x0: &[Real], cfg: &StokesSimpleConfig) -> Vec<Real> {
    cg_solve(|x| matvec(a, x), b, x0, cfg.tol_inner, cfg.max_inner_iters).x
}

/// Collect (DoF, value) pairs from a list of [`StokesBc`].
/// Re-export of the internal [`collect_velocity_pins`] helper so the
/// GPU dispatcher (`crates/molla-fem/src/stokes_gpu.rs`) can build the
/// same `(DoF, value)` pin list as the CPU solver. Kept as a separate
/// `pub` symbol so the internal name stays free for refactors.
#[must_use]
pub fn collect_velocity_pins_pub(bcs: &[StokesBc], dim: usize) -> Vec<(usize, Real)> {
    collect_velocity_pins(bcs, dim)
}

fn collect_velocity_pins(bcs: &[StokesBc], dim: usize) -> Vec<(usize, Real)> {
    let mut pins = Vec::new();
    for bc in bcs {
        match bc {
            StokesBc::NoSlip { node } => {
                let base = (*node as usize) * dim;
                for c in 0..dim {
                    pins.push((base + c, 0.0));
                }
            }
            StokesBc::LidVelocity { node, velocity } => {
                debug_assert_eq!(velocity.len(), dim);
                let base = (*node as usize) * dim;
                for (c, v) in velocity.iter().enumerate() {
                    pins.push((base + c, *v));
                }
            }
            StokesBc::PressureZero { .. } => {}
        }
    }
    pins
}

/// `y = Aᵀ · x`. For a CSR matrix without a precomputed transpose, we
/// fall back to walking the original rows and scattering. `n_cols`
/// is `A.ncols()` (= length of the result).
fn matvec_t(a: &BsrMatrix, x: &[Real], n_cols: usize) -> Vec<Real> {
    debug_assert_eq!(a.b, 1);
    debug_assert_eq!(x.len(), a.nrows());
    let mut y = vec![0.0; n_cols];
    for r in 0..a.block_rows {
        let lo = a.row_offsets[r];
        let hi = a.row_offsets[r + 1];
        let xr = x[r];
        for slot in lo..hi {
            let c = a.col_idx[slot];
            y[c] += a.values[slot] * xr;
        }
    }
    y
}

// ─── Convection assembly (Stage 37.3) ────────────────────────────────
//
// Builds the explicit convective force `f_conv = -∫ N_i (u_old · ∇u_old) dx`
// for the IMEX Navier-Stokes step. The convection block is treated
// **explicitly** (lagged from the previous step), so we don't need the
// full Jacobian — just the per-element contribution evaluated at the
// quadrature points using the previous-step velocity field.
//
// Stage 37.2 (separate parallel agent) is also adding a
// `compute_element_convection` to `element.rs`. To avoid a merge
// conflict we ship our own minimal helper here scoped to Stokes; once
// 37.2 lands the inner per-element loop can switch over.

/// Evaluate the velocity at a triangle quadrature point from the
/// six P2 nodal DoFs `(node, comp)`-flat layout.
#[inline]
fn eval_p2_tri_velocity(n: &[Real; 6], nodes: &[usize; 6], u: &[Real], dim: usize) -> [Real; 3] {
    let mut v = [0.0_f64 as Real; 3];
    for (i, &node) in nodes.iter().enumerate() {
        for c in 0..dim {
            v[c] += n[i] * u[node * dim + c];
        }
    }
    v
}

/// Evaluate the velocity gradient at a triangle quadrature point.
/// Returns `[∂u_c/∂x, ∂u_c/∂y]` for each component `c`.
#[inline]
fn eval_p2_tri_velocity_grad(
    g: &[Vec3; 6],
    nodes: &[usize; 6],
    u: &[Real],
    dim: usize,
) -> [[Real; 2]; 3] {
    let mut gu = [[0.0_f64 as Real; 2]; 3];
    for (i, &node) in nodes.iter().enumerate() {
        for c in 0..dim {
            let uc = u[node * dim + c];
            gu[c][0] += uc * g[i].x;
            gu[c][1] += uc * g[i].y;
        }
    }
    gu
}

/// Evaluate velocity / gradient on a P2 tet at a quadrature point.
#[inline]
fn eval_p2_tet_velocity(n: &[Real; 10], nodes: &[usize; 10], u: &[Real], dim: usize) -> [Real; 3] {
    let mut v = [0.0_f64 as Real; 3];
    for (i, &node) in nodes.iter().enumerate() {
        for c in 0..dim {
            v[c] += n[i] * u[node * dim + c];
        }
    }
    v
}

#[inline]
fn eval_p2_tet_velocity_grad(
    g: &[Vec3; 10],
    nodes: &[usize; 10],
    u: &[Real],
    dim: usize,
) -> [[Real; 3]; 3] {
    let mut gu = [[0.0_f64 as Real; 3]; 3];
    for (i, &node) in nodes.iter().enumerate() {
        for c in 0..dim {
            let uc = u[node * dim + c];
            gu[c][0] += uc * g[i].x;
            gu[c][1] += uc * g[i].y;
            gu[c][2] += uc * g[i].z;
        }
    }
    gu
}

/// Assemble the explicit convective force vector
/// `f_conv = ∫ N_i (u_old · ∇u_old) dx` (sign convention: this is the
/// **convective term moved to the RHS as `-f_conv`** by the time
/// stepper). Returns a velocity-shaped vector with `n_velocity` entries
/// in the same interleaved layout as
/// [`compute_element_stokes_velocity_block`].
///
/// Implemented as a per-element quadrature integral using the
/// previous-step velocity `u_old`. This is the **plain Galerkin**
/// convection — for high-Péclet (convection-dominated) cases use
/// [`assemble_convection_block_with_supg`] which adds Hughes SUPG
/// stabilisation. The plain-Galerkin path keeps mass conservation
/// exact at low Pe; SUPG kicks in to damp checkerboard oscillations
/// when Pe ≫ 1.
pub fn assemble_convection_block(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    u_old: &[Real],
) -> Vec<Real> {
    debug_assert_eq!(u_old.len(), th.n_velocity);
    let dim = th.dim;
    let mut f = vec![0.0_f64 as Real; th.n_velocity];

    for cell in &mesh.cells {
        match cell {
            FemCell::Tri(idx) => {
                let p = [
                    mesh.vertices[idx[0] as usize],
                    mesh.vertices[idx[1] as usize],
                    mesh.vertices[idx[2] as usize],
                ];
                let area = super::element::tri_area_2d(&p);
                let qpts = tri_quadrature_6pt();
                // Local node (P2) → global node mapping for this cell.
                let mut nodes = [0usize; 6];
                for i in 0..6 {
                    nodes[i] = th.map.local_to_global(cell, i);
                }
                for q in &qpts {
                    let n = p2_tri_shape_functions(q.bary);
                    let g = p2_tri_shape_gradients(q.bary, &p);
                    let u_q = eval_p2_tri_velocity(&n, &nodes, u_old, dim);
                    let gu = eval_p2_tri_velocity_grad(&g, &nodes, u_old, dim);
                    // Convection: (u · ∇)u → component c is
                    // u_x ∂u_c/∂x + u_y ∂u_c/∂y.
                    let mut conv = [0.0_f64 as Real; 3];
                    for c in 0..dim {
                        conv[c] = u_q[0] * gu[c][0] + u_q[1] * gu[c][1];
                    }
                    let w = q.weight * area;
                    for i in 0..6 {
                        for c in 0..dim {
                            f[nodes[i] * dim + c] += w * n[i] * conv[c];
                        }
                    }
                }
            }
            FemCell::Tet(idx) => {
                let p = [
                    mesh.vertices[idx[0] as usize],
                    mesh.vertices[idx[1] as usize],
                    mesh.vertices[idx[2] as usize],
                    mesh.vertices[idx[3] as usize],
                ];
                let vol = super::element::tet_volume(&p);
                let qpts = tet_quadrature_11pt();
                let mut nodes = [0usize; 10];
                for i in 0..10 {
                    nodes[i] = th.map.local_to_global(cell, i);
                }
                for q in &qpts {
                    let n = p2_tet_shape_functions(q.bary);
                    let g = p2_tet_shape_gradients(q.bary, &p);
                    let u_q = eval_p2_tet_velocity(&n, &nodes, u_old, dim);
                    let gu = eval_p2_tet_velocity_grad(&g, &nodes, u_old, dim);
                    let mut conv = [0.0_f64 as Real; 3];
                    for c in 0..dim {
                        conv[c] = u_q[0] * gu[c][0] + u_q[1] * gu[c][1] + u_q[2] * gu[c][2];
                    }
                    let w = q.weight * vol;
                    for i in 0..10 {
                        for c in 0..dim {
                            f[nodes[i] * dim + c] += w * n[i] * conv[c];
                        }
                    }
                }
            }
        }
    }
    f
}

/// Hughes SUPG ξ(Pe) function: `ξ = coth(Pe) − 1/Pe`.
/// - `Pe → 0`  → `ξ → Pe/3` (small — minimal stabilisation).
/// - `Pe → ∞`  → `ξ → 1`    (full SUPG strength).
///
/// Branched implementation avoids the costly `coth` (and the cancellation
/// in `coth(x) − 1/x` near zero) by using the leading Taylor term for
/// small `Pe` and the asymptote for large `Pe`.
#[must_use]
fn hughes_xi(pe: Real) -> Real {
    if pe < 1.0e-3 {
        pe / 3.0
    } else if pe > 50.0 {
        1.0 - 1.0 / pe
    } else {
        let e2 = (2.0 * pe).exp();
        let coth = (e2 + 1.0) / (e2 - 1.0);
        coth - 1.0 / pe
    }
}

/// Same as [`assemble_convection_block`] but adds Hughes SUPG
/// (Streamline Upwind Petrov-Galerkin) stabilisation. For each cell
/// the local Péclet number `Pe = |u_q|·h / (2 ν)` selects the SUPG
/// strength `τ = (h / (2 |u_q|)) · ξ(Pe)`, where `ξ(Pe) = coth(Pe) − 1/Pe`
/// (the textbook Hughes formula). The SUPG term integrates
/// `τ · (u·∇N_i) · (u·∇u_c)` against the modified test function
/// `N_i + τ·(u·∇N_i)`.
///
/// `viscosity` is the kinematic viscosity ν used in Pe; pass `0.0` to
/// force `Pe → ∞` and full SUPG strength (only meaningful for inviscid
/// limit problems). `alpha` is a strength multiplier on `τ` (default
/// `1.0` matches the textbook formula; lower values blend toward
/// plain Galerkin).
pub fn assemble_convection_block_with_supg(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    u_old: &[Real],
    viscosity: Real,
    alpha: Real,
) -> Vec<Real> {
    debug_assert_eq!(u_old.len(), th.n_velocity);
    let dim = th.dim;
    let mut f = vec![0.0_f64 as Real; th.n_velocity];

    for cell in &mesh.cells {
        match cell {
            FemCell::Tri(idx) => {
                let p = [
                    mesh.vertices[idx[0] as usize],
                    mesh.vertices[idx[1] as usize],
                    mesh.vertices[idx[2] as usize],
                ];
                let area = super::element::tri_area_2d(&p);
                let h = area.sqrt();
                let qpts = tri_quadrature_6pt();
                let mut nodes = [0usize; 6];
                for i in 0..6 {
                    nodes[i] = th.map.local_to_global(cell, i);
                }
                for q in &qpts {
                    let n = p2_tri_shape_functions(q.bary);
                    let g = p2_tri_shape_gradients(q.bary, &p);
                    let u_q = eval_p2_tri_velocity(&n, &nodes, u_old, dim);
                    let gu = eval_p2_tri_velocity_grad(&g, &nodes, u_old, dim);
                    let umag = (u_q[0] * u_q[0] + u_q[1] * u_q[1]).sqrt();
                    let tau = if umag > 1.0e-30 {
                        let pe = if viscosity > 1.0e-30 {
                            umag * h / (2.0 * viscosity)
                        } else {
                            Real::INFINITY
                        };
                        alpha * (h / (2.0 * umag)) * hughes_xi(pe)
                    } else {
                        0.0
                    };
                    let mut conv = [0.0_f64 as Real; 3];
                    for c in 0..dim {
                        conv[c] = u_q[0] * gu[c][0] + u_q[1] * gu[c][1];
                    }
                    let w = q.weight * area;
                    for i in 0..6 {
                        // Galerkin term: N_i · conv
                        // SUPG term:     τ · (u·∇N_i) · conv
                        let u_dot_grad_ni = u_q[0] * g[i][0] + u_q[1] * g[i][1];
                        let test = n[i] + tau * u_dot_grad_ni;
                        for c in 0..dim {
                            f[nodes[i] * dim + c] += w * test * conv[c];
                        }
                    }
                }
            }
            FemCell::Tet(idx) => {
                let p = [
                    mesh.vertices[idx[0] as usize],
                    mesh.vertices[idx[1] as usize],
                    mesh.vertices[idx[2] as usize],
                    mesh.vertices[idx[3] as usize],
                ];
                let vol = super::element::tet_volume(&p);
                let h = vol.cbrt();
                let qpts = tet_quadrature_11pt();
                let mut nodes = [0usize; 10];
                for i in 0..10 {
                    nodes[i] = th.map.local_to_global(cell, i);
                }
                for q in &qpts {
                    let n = p2_tet_shape_functions(q.bary);
                    let g = p2_tet_shape_gradients(q.bary, &p);
                    let u_q = eval_p2_tet_velocity(&n, &nodes, u_old, dim);
                    let gu = eval_p2_tet_velocity_grad(&g, &nodes, u_old, dim);
                    let umag = (u_q[0] * u_q[0] + u_q[1] * u_q[1] + u_q[2] * u_q[2]).sqrt();
                    let tau = if umag > 1.0e-30 {
                        let pe = if viscosity > 1.0e-30 {
                            umag * h / (2.0 * viscosity)
                        } else {
                            Real::INFINITY
                        };
                        alpha * (h / (2.0 * umag)) * hughes_xi(pe)
                    } else {
                        0.0
                    };
                    let mut conv = [0.0_f64 as Real; 3];
                    for c in 0..dim {
                        conv[c] = u_q[0] * gu[c][0] + u_q[1] * gu[c][1] + u_q[2] * gu[c][2];
                    }
                    let w = q.weight * vol;
                    for i in 0..10 {
                        let u_dot_grad_ni = u_q[0] * g[i][0] + u_q[1] * g[i][1] + u_q[2] * g[i][2];
                        let test = n[i] + tau * u_dot_grad_ni;
                        for c in 0..dim {
                            f[nodes[i] * dim + c] += w * test * conv[c];
                        }
                    }
                }
            }
        }
    }
    f
}

// ─── Solver: transient Navier-Stokes ──────────────────────────────────

/// Navier-Stokes (transient, incompressible) configuration.
#[derive(Clone, Debug)]
pub struct NavierStokesConfig {
    /// SIMPLE config (used inside each implicit time step).
    pub simple: StokesSimpleConfig,
    /// Time step `Δt`.
    pub dt: Real,
    /// Number of time steps.
    pub n_steps: usize,
    /// SUPG (Hughes) stabilisation strength on the convection term.
    /// `0.0` keeps plain Galerkin; `1.0` is the textbook formula.
    /// Set to non-zero on convection-dominated cases (cell Pe ≫ 1)
    /// to suppress checkerboard oscillations. Defaults to `1.0` —
    /// `hughes_xi(Pe)` is small at low Pe so this is a safe default
    /// that adds no spurious damping in the diffusion-dominated
    /// regime.
    pub supg_alpha: Real,
}

impl Default for NavierStokesConfig {
    fn default() -> Self {
        Self {
            simple: StokesSimpleConfig::default(),
            dt: 0.01,
            n_steps: 100,
            supg_alpha: 1.0,
        }
    }
}

/// **Transient** incompressible Navier-Stokes via implicit-Euler in
/// time + SIMPLE in pressure-velocity coupling, with the convective
/// term `(u · ∇) u` lagged from the previous step (semi-implicit).
///
/// Each time step solves
///
/// ```text
///   (M / Δt + A) u* = (M / Δt) u_old + f_ext − Bᵀ p_old − conv(u_old)
/// ```
///
/// with the same pressure-correction step as [`solve_stokes_steady`].
/// The convective term is integrated explicitly as a P2 mass-form RHS
/// contribution `−∫ N_i (u_old · ∇u_old) dx`.
///
/// Returns the velocity / pressure trajectory at the **final** step
/// (call repeatedly for an animation).
pub fn solve_navier_stokes_transient(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    u_init: &[Real],
    p_init: &[Real],
    f_velocity: &[Real],
    viscosity: Real,
    bcs: &[StokesBc],
    cfg: &NavierStokesConfig,
) -> Result<StokesResult> {
    debug_assert_eq!(u_init.len(), th.n_velocity);
    debug_assert_eq!(p_init.len(), th.n_pressure);

    let a = assemble_velocity_block(mesh, th, viscosity)?;
    let m = assemble_velocity_mass(mesh, th)?;
    let b_div = assemble_div_block(mesh, th)?;

    let inv_dt = 1.0 / cfg.dt;
    // Effective LHS for each implicit-Euler step: A_eff = M/dt + A.
    let a_eff = add_csr_scaled(&m, inv_dt, &a, 1.0);

    let mut u = u_init.to_vec();
    let mut p = p_init.to_vec();

    let mut last = StokesResult {
        u: u.clone(),
        p: p.clone(),
        outer_iters: 0,
        div_residual: 0.0,
    };

    // Pinned-DoF set — used to zero the convection contribution on
    // Dirichlet boundaries (the BC reduction will re-pin those rows
    // in `solve_stokes_with_matrices` regardless, but we keep the RHS
    // clean to avoid introducing spurious magnitude into iterative
    // residual norms).
    let pin_set: std::collections::HashSet<usize> = collect_velocity_pins(bcs, th.dim)
        .into_iter()
        .map(|(d, _)| d)
        .collect();

    for _step in 0..cfg.n_steps {
        // Lagged convective term — explicit Picard linearisation.
        // Stage 37.3 wires in the actual `(u·∇)u` integral via
        // [`assemble_convection_block_with_supg`]. With this active
        // the IMEX scheme is
        //   `M(u_new − u_old)/dt + (u_old·∇)u_old + ∇p − μ∇²u_new = f`
        // plus the SUPG perturbation on the test function for the
        // convection term, controlled by `cfg.supg_alpha`. Pass
        // `supg_alpha = 0.0` to fall back to plain Galerkin.
        let mut conv_force = if cfg.supg_alpha > 0.0 {
            assemble_convection_block_with_supg(mesh, th, &u, viscosity, cfg.supg_alpha)
        } else {
            assemble_convection_block(mesh, th, &u)
        };
        for &dof in &pin_set {
            conv_force[dof] = 0.0;
        }

        // RHS for this step: f + (M/dt) u_old − conv.
        let mu = matvec(&m, &u);
        let f_step: Vec<Real> = (0..th.n_velocity)
            .map(|i| f_velocity[i] + inv_dt * mu[i] - conv_force[i])
            .collect();

        // Solve the per-step Stokes system via Uzawa-CG.
        last = solve_stokes_with_matrices(th, &a_eff, &b_div, &f_step, bcs, &cfg.simple)?;
        u = last.u.clone();
        p = last.p.clone();
    }

    Ok(StokesResult {
        u,
        p,
        outer_iters: last.outer_iters,
        div_residual: last.div_residual,
    })
}

/// Lower-level **single-step** Navier-Stokes IMEX advance. Useful for
/// scenes / tests that need to refresh BCs (e.g. analytic Taylor-Green
/// boundary clamps) between steps without reassembling the matrices.
///
/// `a_eff` should be the precomputed `M / Δt + A` LHS, `b_div` the
/// divergence matrix, `m` the velocity mass matrix. Returns the new
/// `(u, p)` state.
pub fn solve_navier_stokes_step(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    a_eff: &BsrMatrix,
    b_div: &BsrMatrix,
    m: &BsrMatrix,
    u_old: &[Real],
    f_velocity: &[Real],
    inv_dt: Real,
    bcs: &[StokesBc],
    simple: &StokesSimpleConfig,
) -> Result<StokesResult> {
    let pin_set: std::collections::HashSet<usize> = collect_velocity_pins(bcs, th.dim)
        .into_iter()
        .map(|(d, _)| d)
        .collect();
    let mut conv_force = assemble_convection_block(mesh, th, u_old);
    for &dof in &pin_set {
        conv_force[dof] = 0.0;
    }
    let mu = matvec(m, u_old);
    let f_step: Vec<Real> = (0..th.n_velocity)
        .map(|i| f_velocity[i] + inv_dt * mu[i] - conv_force[i])
        .collect();
    solve_stokes_with_matrices(th, a_eff, b_div, &f_step, bcs, simple)
}

/// Sparse `αA + βB` for B = 1 BSR matrices. Mirrors the helper in
/// [`crate::fem::solver`] — reproduced here to keep the Stokes module
/// self-contained.
fn add_csr_scaled(a: &BsrMatrix, alpha: Real, b: &BsrMatrix, beta: Real) -> BsrMatrix {
    debug_assert_eq!(a.b, 1);
    debug_assert_eq!(b.b, 1);
    debug_assert_eq!(a.nrows(), b.nrows());
    debug_assert_eq!(a.ncols(), b.ncols());
    let mut triplets: Vec<(usize, usize, Real)> =
        Vec::with_capacity(a.values.len() + b.values.len());
    for r in 0..a.block_rows {
        for slot in a.row_offsets[r]..a.row_offsets[r + 1] {
            let c = a.col_idx[slot];
            triplets.push((r, c, alpha * a.values[slot]));
        }
    }
    for r in 0..b.block_rows {
        for slot in b.row_offsets[r]..b.row_offsets[r + 1] {
            let c = b.col_idx[slot];
            triplets.push((r, c, beta * b.values[slot]));
        }
    }
    BsrMatrix::from_scalar_triplets(a.block_rows, a.block_cols, &triplets)
        .expect("add_csr_scaled: triplet rebuild")
}

// ─── Helpers exposed for tests / scenes ───────────────────────────────

/// Lid-driven-cavity boundary-condition helper. Returns
/// `(bcs, lid_node_ids)` for a 2D unit-square mesh built with
/// [`FemMesh::tri_grid_2d`] of size `nx × ny`.
///
/// The lid is the top face (`y = h`) with prescribed horizontal
/// velocity `lid_velocity`; the other three walls are no-slip; the
/// bottom-left vertex (DoF 0) is the pressure pin.
///
/// Edge nodes are also pinned: every P2 edge whose both endpoints lie
/// on the same wall gets the corresponding velocity (no-slip walls →
/// 0; lid → `lid_velocity`).
#[must_use]
pub fn build_cavity_bcs_2d(
    mesh: &FemMesh,
    th: &MixedTaylorHood,
    h: Real,
    lid_velocity: [Real; 2],
) -> Vec<StokesBc> {
    let mut bcs: Vec<StokesBc> = Vec::new();
    let dim = th.dim;
    debug_assert_eq!(dim, 2, "cavity BCs are 2D only");

    let on_left = |p: Vec3| p.x.abs() < 1e-9;
    let on_right = |p: Vec3| (p.x - 1.0).abs() < 1e-9;
    let on_bottom = |p: Vec3| p.y.abs() < 1e-9;
    let on_top = |p: Vec3| (p.y - h).abs() < 1e-9;
    let _ = on_left;
    let _ = on_right;
    let _ = on_bottom;

    // Corner DoFs (vertex nodes).
    for (i, p) in mesh.vertices.iter().enumerate() {
        let on_wall =
            p.x.abs() < 1e-9 || (p.x - 1.0).abs() < 1e-9 || p.y.abs() < 1e-9 || on_top(*p);
        if !on_wall {
            continue;
        }
        if on_top(*p) && p.x > 1e-9 && p.x < 1.0 - 1e-9 {
            // Top interior → lid velocity. Corner vertices (top-left,
            // top-right) get no-slip to disambiguate the tearing
            // singularity (Ghia-Ghia-Shin convention is "regularised
            // lid", which sets the corner to zero).
            bcs.push(StokesBc::LidVelocity {
                node: i as u32,
                velocity: lid_velocity.to_vec(),
            });
        } else {
            // Bottom / sides / lid corners → no-slip.
            bcs.push(StokesBc::NoSlip { node: i as u32 });
        }
    }

    // Edge DoFs (edge midpoints).
    let (edges, _edge_id) = compute_edges(mesh);
    let edge_dof_offset = th.map.vertex_count;
    for (k, edge) in edges.iter().enumerate() {
        let pa = mesh.vertices[edge[0] as usize];
        let pb = mesh.vertices[edge[1] as usize];
        let on_wall_a =
            pa.x.abs() < 1e-9 || (pa.x - 1.0).abs() < 1e-9 || pa.y.abs() < 1e-9 || on_top(pa);
        let on_wall_b =
            pb.x.abs() < 1e-9 || (pb.x - 1.0).abs() < 1e-9 || pb.y.abs() < 1e-9 || on_top(pb);
        if !(on_wall_a && on_wall_b) {
            continue;
        }
        let mid_x = 0.5 * (pa.x + pb.x);
        let mid_y = 0.5 * (pa.y + pb.y);
        let on_top_edge = (mid_y - h).abs() < 1e-9 && mid_x > 1e-9 && mid_x < 1.0 - 1e-9;
        let edge_node = edge_dof_offset + k;
        if on_top_edge {
            bcs.push(StokesBc::LidVelocity {
                node: edge_node as u32,
                velocity: lid_velocity.to_vec(),
            });
        } else {
            bcs.push(StokesBc::NoSlip {
                node: edge_node as u32,
            });
        }
    }

    // Pressure pin: bottom-left vertex (vertex 0 in the tri-grid).
    bcs.push(StokesBc::PressureZero { vertex: 0 });

    let _ = HashMap::<u32, u32>::new(); // silence the import warning
    bcs
}
