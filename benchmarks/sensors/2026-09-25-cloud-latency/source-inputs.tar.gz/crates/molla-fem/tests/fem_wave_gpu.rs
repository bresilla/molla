//! Stage 36.5 Slice E + Slice H — GPU wave transient parity tests.
//!
//! Verifies that [`molla_fem::WaveStepperGpu::step`] produces the
//! same `(u, v, a)` triple as the CPU [`molla_fem::solve_wave_transient`]
//! on a pinned-boundary 2D wave PDE.
//!
//! **Slice H** changed the GPU stepper to keep `(u, v, a)` resident
//! across timesteps — the new test pattern loops `gpu.step()` for N
//! iterations with no per-step host upload, then reads back the final
//! state and compares to the CPU oracle looped from the same initial
//! state.
//!
//! All tests are `#[ignore]` because they need a real wgpu adapter.
//! Run with `nixVulkan cargo test -p molla-fem --test fem_wave_gpu -- --ignored`.

#![cfg(feature = "gpu")]

use std::sync::Mutex;

use molla_compute::Engine;
use molla_fem::{
    BoundaryCondition, FemMesh, FunctionSpace, NEWMARK_BETA_DEFAULT, NEWMARK_GAMMA_DEFAULT,
    WaveStepperGpu, assemble_global, compute_element_mass, compute_element_wave_stiffness,
    solve_wave_transient,
};
use molla_math::Real;
use molla_math::sparse::BsrMatrix;

/// Serialise wgpu adapter ownership across the tests in this binary
/// — same pattern as `tests/fem_gpu.rs`.
static GPU_LOCK: Mutex<()> = Mutex::new(());

fn assemble_mass(mesh: &FemMesh) -> BsrMatrix {
    assemble_global(mesh, FunctionSpace::P1Nodal, |c, v| {
        compute_element_mass(c, v)
    })
    .expect("mass assembly")
}

fn assemble_wave_stiffness(mesh: &FemMesh, c2: Real) -> BsrMatrix {
    assemble_global(mesh, FunctionSpace::P1Nodal, |c, v| {
        compute_element_wave_stiffness(c, v, c2)
    })
    .expect("stiffness assembly")
}

/// Build the WarpWave-style problem: `n_grid × n_grid` triangle mesh
/// on the unit square, all boundary verts pinned to zero, Gaussian
/// initial displacement at the centre.
fn build_warpwave(n_grid: usize) -> (FemMesh, Vec<BoundaryCondition>, Vec<Real>) {
    let mesh = FemMesh::tri_grid_2d(n_grid, n_grid, 1.0, 1.0);
    let mut bcs = Vec::new();
    for (i, p) in mesh.vertices.iter().enumerate() {
        if p.x <= 1e-9 || p.x >= 1.0 - 1e-9 || p.y <= 1e-9 || p.y >= 1.0 - 1e-9 {
            bcs.push(BoundaryCondition::Dirichlet {
                vertex: i as u32,
                value: 0.0,
            });
        }
    }
    let mut u_init = vec![0.0_f64 as Real; mesh.vert_count()];
    for (i, p) in mesh.vertices.iter().enumerate() {
        let dx = p.x - 0.5;
        let dy = p.y - 0.5;
        let r2 = dx * dx + dy * dy;
        u_init[i] = (-r2 * 50.0).exp();
    }
    // Re-zero the boundary so the initial state is BC-consistent.
    for bc in &bcs {
        if let BoundaryCondition::Dirichlet { vertex, value } = bc {
            u_init[*vertex as usize] = *value;
        }
    }
    (mesh, bcs, u_init)
}

#[test]
#[ignore = "needs a real wgpu adapter — run via nixVulkan cargo test"]
fn gpu_wave_step_matches_cpu_oracle() {
    let _gpu_lock = GPU_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    // 16×16 grid — small enough to converge fast, large enough that
    // the f32 round-off doesn't dominate the comparison.
    let (mesh, bcs, u_init) = build_warpwave(16);
    let m = assemble_mass(&mesh);
    let k = assemble_wave_stiffness(&mesh, 1.0);

    let dt: Real = 0.005;
    let beta = NEWMARK_BETA_DEFAULT;
    let gamma = NEWMARK_GAMMA_DEFAULT;
    let n = mesh.vert_count();

    // Initial state: u = Gaussian, v = a = 0.
    let mut u_cpu = u_init.clone();
    let mut v_cpu = vec![0.0; n];
    let mut a_cpu = vec![0.0; n];
    let v0 = vec![0.0; n];
    let a0 = vec![0.0; n];

    let engine = Engine::new_gpu().expect("gpu");
    // Slice H — initial (u, v, a) are uploaded once at construction;
    // step() runs entirely on GPU thereafter.
    let mut stepper = WaveStepperGpu::new(
        &engine, &mesh, &m, &k, dt, beta, gamma, &bcs, &u_init, &v0, &a0,
    )
    .expect("WaveStepperGpu::new");

    // Step 50 times on both paths; CPU keeps host vectors in sync,
    // GPU mutates persistent buffers.
    let n_steps = 50;
    for _ in 0..n_steps {
        let cpu = solve_wave_transient(&m, &k, &u_cpu, &v_cpu, &a_cpu, dt, beta, gamma, &bcs);
        let _gpu_stats = stepper.step().expect("gpu step");
        u_cpu = cpu.u_new;
        v_cpu = cpu.v_new;
        a_cpu = cpu.a_new;
    }

    // Read back the final GPU state and compare.
    let (u_gpu, v_gpu, a_gpu) = stepper.read_state().expect("gpu read_state");
    let mut max_du: Real = 0.0;
    let mut max_dv: Real = 0.0;
    let mut max_da: Real = 0.0;
    for i in 0..n {
        max_du = max_du.max((u_cpu[i] - u_gpu[i]).abs());
        max_dv = max_dv.max((v_cpu[i] - v_gpu[i]).abs());
        max_da = max_da.max((a_cpu[i] - a_gpu[i]).abs());
    }
    eprintln!(
        "gpu_wave_step_matches_cpu_oracle: n = {n}, {n_steps} steps, \
         final max |Δu| = {max_du:.3e}, |Δv| = {max_dv:.3e}, |Δa| = {max_da:.3e}",
    );
    // f32 GPU + f64 CPU + 50 steps of error accumulation — 1e-3 is
    // loose but well within the published GPU FEM precision budget.
    assert!(max_du < 1e-3, "final max |Δu| = {max_du:.3e}");
    assert!(max_dv < 1e-2, "final max |Δv| = {max_dv:.3e}");
    assert!(max_da < 1.0, "final max |Δa| = {max_da:.3e}");
}

#[test]
#[ignore = "needs a real wgpu adapter — run via nixVulkan cargo test"]
fn gpu_wave_stepper_accepts_nonzero_dirichlet() {
    let _gpu_lock = GPU_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    // Slice G: nonzero Dirichlet is supported via the precomputed
    // column shift. Slice H: stepper is now persistent — verify one
    // step matches the CPU oracle on a problem with a non-zero pinned
    // boundary value.
    let mesh = FemMesh::tri_grid_2d(8, 8, 1.0, 1.0);
    let m = assemble_mass(&mesh);
    let k = assemble_wave_stiffness(&mesh, 1.0);
    let n = mesh.vert_count();
    // Pin the corner to a nonzero displacement.
    let bcs = vec![BoundaryCondition::Dirichlet {
        vertex: 0,
        value: 0.5,
    }];

    // Initial state: BC-consistent (pinned vertex at 0.5).
    let mut u_init = vec![0.0; n];
    u_init[0] = 0.5;
    let v0 = vec![0.0; n];
    let a0 = vec![0.0; n];

    let engine = Engine::new_gpu().expect("gpu");
    let mut stepper = WaveStepperGpu::new(
        &engine,
        &mesh,
        &m,
        &k,
        0.01,
        NEWMARK_BETA_DEFAULT,
        NEWMARK_GAMMA_DEFAULT,
        &bcs,
        &u_init,
        &v0,
        &a0,
    )
    .expect("stepper builds with nonzero Dirichlet");

    let cpu = solve_wave_transient(
        &m,
        &k,
        &u_init,
        &v0,
        &a0,
        0.01,
        NEWMARK_BETA_DEFAULT,
        NEWMARK_GAMMA_DEFAULT,
        &bcs,
    );
    stepper.step().expect("step");
    let u_gpu = stepper.read_u().expect("read_u");
    let mut max_du: Real = 0.0;
    for i in 0..n {
        max_du = max_du.max((cpu.u_new[i] - u_gpu[i]).abs());
    }
    assert!(
        max_du < 1e-3,
        "nonzero-Dirichlet single-step max |Δu| = {max_du:.3e}",
    );
    assert!((u_gpu[0] - 0.5).abs() < 1e-5, "pinned DoF must hold");
}

/// Interleave a scalar CSR system into `dim` decoupled components
/// (same helper as in `fem_transient_gpu.rs`): scalar entry
/// `(i, j, v)` becomes `(i·dim + c, j·dim + c, v)`, so the scalar CPU
/// solver run once per component is an exact oracle for the vector
/// system.
fn interleave_csr(a: &BsrMatrix, dim: usize) -> BsrMatrix {
    let n = a.nrows();
    let mut row_offsets = Vec::with_capacity(n * dim + 1);
    let mut col_idx = Vec::new();
    let mut values = Vec::new();
    row_offsets.push(0usize);
    for i in 0..n {
        for c in 0..dim {
            for s in a.row_offsets[i]..a.row_offsets[i + 1] {
                col_idx.push(a.col_idx[s] * dim + c);
                values.push(a.values[s]);
            }
            row_offsets.push(col_idx.len());
        }
    }
    BsrMatrix {
        b: 1,
        block_rows: n * dim,
        block_cols: n * dim,
        row_offsets,
        col_idx,
        values,
    }
}

/// INSPECTION B2 — vector Dirichlet BCs on the GPU wave stepper (the
/// Newmark twin of `gpu_transient_vector_dirichlet_matches_componentwise_cpu`).
/// Each boundary vertex pins a different value per component; before
/// the fix the stepper truncated to `values[0]` in release builds.
#[test]
#[ignore = "needs a real wgpu adapter — run via nixVulkan cargo test"]
fn gpu_wave_vector_dirichlet_matches_componentwise_cpu() {
    let _gpu_lock = GPU_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    let (mesh, bcs_scalar, u_init_scalar) = build_warpwave(12);
    let nv = mesh.vert_count();
    let dim = 2usize;
    let m = assemble_mass(&mesh);
    let k = assemble_wave_stiffness(&mesh, 1.0);
    let m2 = interleave_csr(&m, dim);
    let k2 = interleave_csr(&k, dim);

    // Boundary vertices from the scalar fixture, re-pinned per
    // component: component 0 keeps the scalar zero BC, component 1
    // pins 0.25.
    let pin_vals = [0.0 as Real, 0.25];
    let boundary: Vec<u32> = bcs_scalar
        .iter()
        .filter_map(|bc| match bc {
            BoundaryCondition::Dirichlet { vertex, .. } => Some(*vertex),
            _ => None,
        })
        .collect();
    let bcs2: Vec<BoundaryCondition> = boundary
        .iter()
        .map(|&v| BoundaryCondition::DirichletVector {
            vertex: v,
            values: pin_vals.to_vec(),
        })
        .collect();

    // Initial state: component 0 = the Gaussian bump, component 1 =
    // half the bump plus the pin offset; v = a = 0. Pinned rows preset
    // to their BC value.
    let mut u2_init = vec![0.0 as Real; nv * dim];
    for i in 0..nv {
        u2_init[i * dim] = u_init_scalar[i];
        u2_init[i * dim + 1] = 0.5 * u_init_scalar[i] + pin_vals[1];
    }
    for &v in &boundary {
        u2_init[v as usize * dim] = pin_vals[0];
        u2_init[v as usize * dim + 1] = pin_vals[1];
    }
    let v0 = vec![0.0; nv * dim];
    let a0 = vec![0.0; nv * dim];

    let dt: Real = 0.005;
    let beta = NEWMARK_BETA_DEFAULT;
    let gamma = NEWMARK_GAMMA_DEFAULT;

    let engine = Engine::new_gpu().expect("gpu");
    let mut stepper = WaveStepperGpu::new(
        &engine, &mesh, &m2, &k2, dt, beta, gamma, &bcs2, &u2_init, &v0, &a0,
    )
    .expect("vector WaveStepperGpu::new");

    let n_steps = 40;
    for _ in 0..n_steps {
        stepper.step().expect("gpu wave step");
    }
    let (u2_gpu, _v2_gpu, _a2_gpu) = stepper.read_state().expect("gpu read_state");

    // Oracle: scalar CPU Newmark per component.
    let mut max_du: Real = 0.0;
    for c in 0..dim {
        let bcs_c: Vec<BoundaryCondition> = boundary
            .iter()
            .map(|&v| BoundaryCondition::Dirichlet {
                vertex: v,
                value: pin_vals[c],
            })
            .collect();
        let mut u_c: Vec<Real> = (0..nv).map(|i| u2_init[i * dim + c]).collect();
        let mut v_c = vec![0.0; nv];
        let mut a_c = vec![0.0; nv];
        for _ in 0..n_steps {
            let out = solve_wave_transient(&m, &k, &u_c, &v_c, &a_c, dt, beta, gamma, &bcs_c);
            u_c = out.u_new;
            v_c = out.v_new;
            a_c = out.a_new;
        }
        for i in 0..nv {
            max_du = max_du.max((u_c[i] - u2_gpu[i * dim + c]).abs());
        }
    }
    eprintln!(
        "gpu_wave_vector_dirichlet: nv = {nv}, dim = {dim}, {n_steps} steps, \
         max |Δu| = {max_du:.3e}",
    );
    assert!(max_du < 1e-3, "final max |Δu| = {max_du:.3e}");

    // Every pinned component must hold its own value.
    for &v in &boundary {
        for c in 0..dim {
            let got = u2_gpu[v as usize * dim + c];
            assert!(
                (got - pin_vals[c]).abs() < 1e-5,
                "pinned component must hold: vertex {v} comp {c} = {got}, want {}",
                pin_vals[c]
            );
        }
    }
}
